
import React from 'react'
import type { AnyMsg, LoadDocMsg, HighlightMsg } from '../shared/messages'
export const Viewer:React.FC=()=>{
  const [pdfUrl,setPdfUrl]=React.useState<string|null>(null)
  const [bbox,setBbox]=React.useState<[number,number,number,number]|null>(null)
  React.useEffect(()=>{
    function onMsg(ev:MessageEvent){
      if(ev.origin!==window.location.origin) return
      const msg = ev.data as AnyMsg
      if(msg.kind==='LOAD_DOC'){ setPdfUrl((msg as LoadDocMsg).pdfUrl); setBbox(null) }
      else if(msg.kind==='HIGHLIGHT_FIELD'){ setBbox((msg as HighlightMsg).bbox) }
    }
    window.addEventListener('message', onMsg)
    window.opener?.postMessage({kind:'READY', viewerId:crypto.randomUUID()}, window.location.origin)
    return ()=>window.removeEventListener('message', onMsg)
  },[])
  return (
    <div style={{height:'calc(100vh - 100px)', padding:16}}>
      <div style={{position:'relative', margin:'0 auto', width:'85%', height:'100%', background:'#0d152d', border:'1px solid #1a274f'}}>
        {pdfUrl ? (
          <>
            <iframe src={pdfUrl} title="pdf" style={{position:'absolute',inset:0,width:'100%',height:'100%',border:'none',background:'#fff'}}/>
            {bbox && <div className="highlight" style={{
              left: bbox[0]*100+'%', top: bbox[1]*100+'%',
              width: (bbox[2]-bbox[0])*100+'%', height: (bbox[3]-bbox[1])*100+'%'
            }}/>}
          </>
        ) : <div style={{color:'#9fb0d8', padding:24}}>Waiting for LOAD_DOC…</div>}
      </div>
    </div>
  )
}
