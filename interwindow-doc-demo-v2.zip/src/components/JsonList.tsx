
import React from 'react'
type Props = { json:any; onClick:(node:any)=>void }

function flatten(json:any){
  const out:any[]=[]
  const root=Array.isArray(json)?json[0]:json
  const props=Array.isArray(root?.properties)?root.properties[0]:root?.properties||{}
  const meta=props?.metadataMap||{}
  const pages=props?.pages||[]

  Object.entries(meta).forEach(([key, field]:any)=>{
    const v=field?.bounding_poly?.normalized_vertices
    if(v) out.push({key, fieldData:field, value:field?.value})
  })
  pages.forEach((p:any,i:number)=>{
    (p.elements||[]).forEach((el:any,j:number)=>{
      const v=el?.boundingBox?.normalizedVertices
      if(v) out.push({key:`page_${i+1}_el_${j}`, value:el?.content, fieldData:{bounding_poly:{normalized_vertices:v}, confidence:el?.confidence, source:'element'}})
    })
  })
  return out
}

export const JsonList:React.FC<Props>=({json,onClick})=>{
  const rows=React.useMemo(()=>flatten(json),[json])
  if(!rows.length) return <div className="viewerInfo">No elements with normalized vertices found.</div>
  return <div className="list">
    {rows.map((r,i)=>(<div key={i} className="jsonItem" onClick={()=>onClick(r)}>
      <div style={{display:'flex',justifyContent:'space-between',gap:8}}>
        <b>{r.key}</b><span style={{color:'#9fb0d8',fontSize:12}}>{(r.value||'').toString().slice(0,60)}</span>
      </div>
    </div>))}
  </div>
}
