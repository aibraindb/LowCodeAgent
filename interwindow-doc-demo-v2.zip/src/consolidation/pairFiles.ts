
export type DocPair = { base:string; pdfUrl:string; jsonUrl:string; docType:string }
export type Pairing = { paired: DocPair[]; lonePdfs: string[]; loneJsons: string[] }

function baseKey(name:string){ return name.replace(/\.[^.]+$/,'') }

export async function buildPairs(list: FileList): Promise<Pairing> {
  const files = Array.from(list)
  const map = new Map<string, any>()
  const lonePdfs:string[] = [], loneJsons:string[] = []

  for (const f of files) {
    const base = baseKey(f.name)
    const e = map.get(base) || { base }
    if (/\.pdf$/i.test(f.name)) e.pdfUrl = URL.createObjectURL(f)
    else if (/\.(json|txt)$/i.test(f.name)) {
      e.jsonUrl = URL.createObjectURL(f)
      const m = f.name.match(/(invoice|lease|fds|guarantee|acceptance)/i)
      if (m) e.docType = m[1].toLowerCase()
    }
    map.set(base, e)
  }

  const paired: DocPair[] = []
  for (const e of map.values()) {
    if (e.pdfUrl && e.jsonUrl) paired.push({ base:e.base, pdfUrl:e.pdfUrl, jsonUrl:e.jsonUrl, docType:e.docType || infer(e.base) })
    else if (e.pdfUrl) lonePdfs.push(e.base+'.pdf')
    else if (e.jsonUrl) loneJsons.push(e.base+'.json')
  }
  return { paired, lonePdfs, loneJsons }
}
function infer(s:string){ const m=s.match(/(invoice|lease|fds|guarantee|acceptance)/i); return m?m[1].toLowerCase():'unknown' }
