
import React from 'react'
import { buildPairs, type DocPair } from './pairFiles'
import { openOrAttach, getChild } from './OpenManager'
import type { HighlightMsg } from '../shared/messages'
import { JsonList } from '../components/JsonList'

export const ConsolidationPanel:React.FC=()=>{
  const [pairs,setPairs]=React.useState<DocPair[]>([])
  const [lonePdfs,setLonePdfs]=React.useState<string[]>([])
  const [loneJsons,setLoneJsons]=React.useState<string[]>([])
  const [selected,setSelected]=React.useState<DocPair|null>(null)
  const [json,setJson]=React.useState<any>(null)

  async function onFiles(e:React.ChangeEvent<HTMLInputElement>){
    if(!e.target.files?.length) return
    const res=await buildPairs(e.target.files)
    setPairs(res.paired); setLonePdfs(res.lonePdfs); setLoneJsons(res.loneJsons)
    setSelected(null); setJson(null)
  }

  async function loadJson(p:DocPair){
    setSelected(p)
    const j = await fetch(p.jsonUrl).then(r=>r.json()).catch(()=>null)
    setJson(j)
  }

  function bboxFromNode(node:any):[number,number,number,number]|null{
    const v=node?.fieldData?.bounding_poly?.normalized_vertices; if(!v) return null
    const xs=v.map((p:any)=>Number(p.x||0)), ys=v.map((p:any)=>Number(p.y||0))
    return [Math.min(...xs), Math.min(...ys), Math.max(...xs), Math.max(...ys)]
  }

  function onJsonClick(node:any){
    if(!selected) return
    const bbox=bboxFromNode(node); if(!bbox) return
    const child=getChild(selected.docType)
    if(!child){ openOrAttach(selected); setTimeout(()=>onJsonClick(node), 300); return }
    const msg:HighlightMsg={kind:'HIGHLIGHT_FIELD', base:selected.base, bbox}
    child.postMessage(msg, window.location.origin)
  }

  return (<>
    <div className="panel">
      <div className="sectionTitle">Dataset</div>
      <input type="file" multiple accept=".pdf,.PDF,.json,.JSON,.txt" onChange={onFiles}/>
      <div style={{height:8}}/>
      {!pairs.length ? (
        <div className="hero"><div className="heroInner">
          <h2>Drop in PDFs + DocAI JSONs</h2>
          <p>Auto-pairs by filename. Open documents in type-specific tabs. Click JSON rows to highlight in the viewer.</p>
        </div></div>
      ) : (
        <>
          <div className="sectionTitle">Paired Files</div>
          {pairs.map((p,i)=>(
            <div key={i} className="fileRow">
              <span className="badge">{p.docType}</span>
              <span style={{fontFamily:'monospace',fontSize:13}}>{p.base}</span>
              <span style={{marginLeft:'auto'}}/>
              <button className="btn" onClick={()=>openOrAttach(p)}>Open</button>
              <button className="btn ghost" onClick={()=>loadJson(p)}>JSON</button>
            </div>
          ))}
          {(lonePdfs.length||loneJsons.length) && (
            <>
              {lonePdfs.length ? <div className="sectionTitle">Unpaired PDFs</div> : null}
              {lonePdfs.map((n,i)=><div key={'p'+i} className="fileRow">{n}</div>)}
              {loneJsons.length ? <div className="sectionTitle">Unpaired JSONs</div> : null}
              {loneJsons.map((n,i)=><div key={'j'+i} className="fileRow">{n}</div>)}
            </>
          )}
        </>
      )}
    </div>
    <div className="jsonPane">
      {json ? <JsonList json={json} onClick={onJsonClick}/> :
        <div className="viewerInfo">Select a pair and click <b>JSON</b> to preview.</div>}
    </div>
  </>)
}
