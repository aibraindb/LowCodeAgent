
import React from 'react'
import { ConsolidationPanel } from './consolidation/ConsolidationPanel'
import { Viewer } from './viewer/Viewer'

export const App: React.FC = () => {
  const path = window.location.pathname
  return (
    <>
      <div className="header">
        <h1>Wells Document Console</h1>
        <p>Open docs in dedicated tabs by type • Click JSON to highlight fields • Parent ↔ viewer messaging</p>
      </div>
      {path.startsWith('/viewer') ? <Viewer/> : <div className="grid"><ConsolidationPanel/></div>}
    </>
  )
}
